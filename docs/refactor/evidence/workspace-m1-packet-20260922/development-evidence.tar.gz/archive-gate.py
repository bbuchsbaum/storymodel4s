from pathlib import Path
import datetime,hashlib,json,re,tarfile,subprocess,xml.etree.ElementTree as ET
root=Path('/private/tmp/storymodel4s-workspace-m1-20260922')
ev=Path('/private/tmp/workspace-m1-evidence/packet')
out=ev/'qualified-f4af92e8';out.mkdir(exist_ok=True)
meta=json.loads((ev/'final-checkAll-2.log.meta.json').read_text())
assert meta['exit_code']==0,meta
binding=json.loads((ev/'final-source-binding-2.json').read_text())
run=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert run('rev-parse','HEAD')==binding['sha']
assert not run('status','--porcelain')
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
log=ev/'final-checkAll-2.log';text=log.read_text()
modules=['core','proposition','amrInterop','features','acquire','story','document','recall','align','interview','embedCore','view','codec','corpus','fixtures','laws']
tasks=[f'{m}{p}/test' for m in modules for p in ['JVM','JS','Native']]+[f'{m}/test' for m in ['providerParser','providerAgent','embedGrakern','embedOnnx','embedBench','media','pipeline','corpusIntake']]
lines=[x for x in text.splitlines() if re.match(r'\[info\] (?:Passed|Failed): Total ',x)]
assert len(lines)==len(tasks),(len(lines),len(tasks))
counts={k:0 for k in ['Total','Passed','Failed','Errors','Skipped','Ignored']}
receipts=[]
for name,line in zip(tasks,lines):
 c={k:0 for k in counts};c.update({k:int(v) for k,v in re.findall(r'(Total|Passed|Failed|Errors|Skipped|Ignored) (\d+)',line)})
 for k,v in c.items():counts[k]+=v
 receipts.append(dict(task=name,counts=c,summary=line))
assert counts['Failed']==counts['Errors']==0
assert counts['Total']==counts['Passed']+counts['Skipped']+counts['Ignored']
started=datetime.datetime.fromisoformat(meta['started_utc']).timestamp()
reports=[];stale=[];skips=[];xml_counts={k:0 for k in ['tests','failures','errors','skipped']}
for p in sorted(root.glob('**/target/test-reports/TEST-*.xml')):
 rel=p.relative_to(root).as_posix()
 if p.stat().st_mtime<started-1:
  stale.append(rel);continue
 doc=ET.parse(p).getroot()
 for k in xml_counts:xml_counts[k]+=int(doc.get(k,'0'))
 for test in doc.findall('.//testcase'):
  skip=test.find('skipped')
  if skip is not None:skips.append(dict(suite=doc.get('name'),test=test.get('name'),reason=skip.get('message') or skip.text or ''))
 reports.append(dict(path=rel,sha256=hashfile(p),fresh=True))
assert reports
assert xml_counts['failures']==xml_counts['errors']==0,xml_counts
archive=out/'checkAll.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in [log,ev/'final-checkAll-2.log.meta.json',ev/'final-source-binding-2.json',ev/'reference-scope-f4af92e8.log',ev/'reference-scope-f4af92e8.log.meta.json']:
  tar.add(p,arcname=p.name)
 for r in reports:tar.add(root/r['path'],arcname='reports/'+r['path'])
receipt=dict(schema='storymodel4s.workspace-m1-final-gate/v1',source=binding['sha'],mergeBase=binding['base'],cleanTrackedAndUntrackedTree=True,commandReceipt=meta,logSha256=hashfile(log),tasks=receipts,counts=counts,skips=skips,warnings=sorted(set(x for x in text.splitlines() if x.startswith('[warn]'))),junit=reports,junitCounts=xml_counts,staleReportsNotEvidence=stale,archiveSha256=hashfile(archive))
(out/'checkAll.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(source=binding['sha'],counts=counts,junit=len(reports),junitCounts=xml_counts,skips=skips,warnings=receipt['warnings'],stale=len(stale)),indent=2))
