#!/usr/bin/env python3
"""Restoring, sequential G1 measure mutations with retained command receipts."""
import hashlib, json, re, subprocess, sys
from pathlib import Path
root,out,dep=map(lambda s:Path(s).resolve(),sys.argv[1:4])
mode=sys.argv[4] if len(sys.argv)>4 else 'runtime'
out.mkdir(parents=True,exist_ok=True)
paths={n:root/'align/src/main/scala/storymodel4s/align'/n for n in ['mappingbinding.scala','mappingmeasures.scala','mappingsourcerender.scala']}
original={n:p.read_text() for n,p in paths.items()}
hashof=lambda s:hashlib.sha256(s.encode()).hexdigest()
B='mappingbinding.scala'; M='mappingmeasures.scala'; S='mappingsourcerender.scala'
def edits(*changes):
 result={}
 for name,old,new in changes:
  value=result.get(name,original[name]);assert value.count(old)==1,(name,old,value.count(old))
  result[name]=value.replace(old,new)
 return result
runtime=[
 ('sum-one-omitted',edits((M,'else if !(math.abs(sum - 1.0) <= MappingTolerance.RowSum) then','else if !(math.abs(sum - 1.0) <= MappingTolerance.RowSum) && false then')),'unnormalized mass refuses'),
 ('mode-implies-assessed',edits((M,'fidelity = target.propositional match','fidelity = PropositionalScope.Declared match')),'undeclared scope NotAssessed and twin view yields NotAssessed'),
 ('unit-zero-fidelity',edits((M,'recalled.proposition,','recall.ordered.head.proposition,')),"fidelity on the link's own unit"),
 ('unit-zero-derived-origin',edits((B,'FromResult.checked(binding, unit)','FromResult.checked(binding, result.posterior.rows.head.unit)')),'raw costs retain their originating unit and binding'),
 ('unit-zero-posterior-origin',edits((M,'new ModelPosterior(unit, row.mass, stage, binding)','new ModelPosterior(result.posterior.rows.head.unit, row.mass, stage, binding)')),'model posterior preserves full state keys and exact values'),
 ('binding-recall-check-omitted',edits((B,'if result.recallChecksum != AlignWire.recallChecksum(recall) then','if result.recallChecksum != AlignWire.recallChecksum(recall) && false then')),'foreign recall sharing unit IDs refuses'),
 ('inventory-check-omitted',edits((B,'else if !inventory.describes(recall) then','else if !inventory.describes(recall) && false then')),'binding refuses a foreign inventory'),
 ('result-content-check-omitted',edits((B,'else if MappingBindingRender.result(result) != resultDigest then','else if MappingBindingRender.result(result) != resultDigest && false then')),'posterior from a foreign result refuses'),
 ('posterior-producer-binding-omitted',edits((M,'binding.checkResult(result).flatMap { _ =>','Right(()).flatMap { _ =>')),'posterior from a foreign result refuses'),
 ('recall-supplement-check-omitted',edits((B,'else if MappingBindingRender.recall(recall) != recallSupplement then','else if MappingBindingRender.recall(recall) != recallSupplement && false then')),'recall predicate preserves None versus Some empty'),
 ('binding-scope-check-omitted',edits((B,'else if MappingSourceRender.scope(checkedView.nodes) != source.scopeDigest then','else if MappingSourceRender.scope(checkedView.nodes) != source.scopeDigest && false then')),'Declared twin view refuses binding'),
 ('unbound-view-scope-trusted',edits(
  (B,'else if MappingSourceRender.scope(\n        view.nodes\n      ) != scopeDigest || source.scopeDigest != scopeDigest','else if (MappingSourceRender.scope(\n        view.nodes\n      ) != scopeDigest || source.scopeDigest != scopeDigest) && false'),
  (M,'fidelity = target.propositional match','fidelity = node.propositional match')),'Declared twin view refuses binding'),
 ('authored-support-evaluated',edits((M,'TermSupport.NotComputed.derived(),','TermSupport.Evaluated.derived(SupportAssessment.externalState),')),'authored links NotComputed(NoCostBreakdown)'),
 ('unbound-lookup-restored',edits((M,'node <- checkedView.node(ref)','node <- view.node(ref)')),'fidelity consumes the checked inventory instead of an unbound lookup'),
 ('mutable-view-used-without-snapshot',edits((M,'val checkedView = MappingBindingRender.snapshot(view)','val checkedView = view')),'binding checks and fidelity consume one captured node inventory'),
 ('binding-mutable-view-used',edits((B,'val checkedView = MappingBindingRender.snapshot(view)','val checkedView = view')),'binding construction consumes one captured node inventory')
]
for field in ['predicate','outcome','cause']:
 runtime.append((f'recall-{field}-presence-collapsed',edits((B,f'optional(p.{field})',f'p.{field}.getOrElse("")')),f'recall {field} preserves None versus Some empty'))
 runtime.append((f'source-{field}-presence-collapsed',edits((S,f'optional(n.{field})',f'n.{field}.getOrElse("")')),f'source {field} preserves None versus Some empty'))
start=original[B].index('  def snapshot(view: SourceView):')
end=original[B].index('  private def number',start)
old_snapshot=original[B][start:end]
restored_semantic_default="""  def snapshot(view: SourceView): SourceView =
    val nodes = view.nodes
    val edges = RelationLayer.values.toVector.map { layer =>
      layer -> view.adjacency(layer).toVector.flatMap { (from, row) => row.toVector.map((to, weight) => (from, to, weight)) }
    }.toMap
    InMemorySourceView(nodes, edges, view.worldOrder, view.scoringLength)

"""
runtime.append(('snapshot-invents-hierarchy',edits((B,old_snapshot,restored_semantic_default)),'snapshot preserves explicitly empty hierarchy adjacency'))
doors=[
 ('posterior-matrix-door',edits((M,'object ModelPosterior:\n','''object ModelPosterior:
  def of(matrix: AlignmentMatrix, unit: RecallUnitId, binding: DerivationBinding, stage: StageEntryId): Either[MappingRefusal, ModelPosterior] =
    matrix.row(unit).toRight(MappingRefusal.UnknownUnit(unit)).map(row => new ModelPosterior(unit, row.mass, stage, binding))
''')),'posterior requires a result not a matrix or transport'),
 ('transport-posterior-conversion-door',edits((M,'object ModelPosterior:\n','''object ModelPosterior:
  given Conversion[TransportMass, ModelPosterior] with
    def apply(value: TransportMass): ModelPosterior = value.asInstanceOf[ModelPosterior]
''')),'posterior requires a result not a matrix or transport'),
 ('gated-factories-package-door',{M:original[M].replace('private[MappingLink]', 'private[align]')},'gated and assessed statuses have no caller door'),
 ('calibrated-probability-door',{M:original[M]+'''
object CalibratedProbability:
  def of(event: CalibratedEvent, probability: Probability, artifact: CalibrationArtifactId): CalibratedProbability = new CalibratedProbability(event, probability, artifact)
'''},'calibrated probability has no door')
]
mutations=doors if mode=='doors' else runtime
if len(sys.argv)>5:
 mutations=mutations[int(sys.argv[5])-1:]
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py'
base=['sbt','-batch','-Dsbt.global.staging=/private/tmp/storymodel4s-m1-sbt-staging-20260922',f'-Dstorymodel4s.grakern.build={dep}']
receipts=[]
def run(name,commands):
 log=out/(name+'.log')
 command=[sys.executable,wrapper,'--log',str(log),'--timeout','2400','--',*base,*commands]
 cp=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/(name+'.wrapper.txt')).write_text(cp.stdout)
 text=log.read_text()
 return cp.returncode,dict(metadata=json.loads(Path(str(log)+'.meta.json').read_text()),logSha256=hashlib.sha256(log.read_bytes()).hexdigest(),totals=re.findall(r'^.*(?:Passed|Failed): Total.*$',text,re.M),failures=[line for line in text.splitlines() if '==> X' in line])
def restore():
 for name,path in paths.items():path.write_text(original[name])
try:
 for name,mutant,expected in mutations:
  for platform in (['JVM','JS','Native'] if mode=='doors' else ['JVM']):
   restore()
   for filename,value in mutant.items():paths[filename].write_text(value)
   project='align'+platform
   commands=[f'{project}/Compile/clean',f'{project}/Test/clean'] if mode=='doors' else []
   pattern='*MappingMeasuresUnforgeableSuite *MappingMeasuresPackageAttackSuite' if mode=='doors' else '*MappingMeasuresSuite *MappingPresenceSuite'
   commands.append(f'{project}/testOnly {pattern}')
   code,receipt=run(name+'-'+platform,commands)
   receipt.update(name=name,platform=platform,sourceSha256={n:hashof(original[n]) for n in mutant},mutantSha256={n:hashof(v) for n,v in mutant.items()},command=commands,cleanCompileAndTest=mode=='doors',expectedFailure=expected)
   receipt['killed']=code!=0 and bool(receipt['totals']) and expected in '\n'.join(receipt['failures'])
   receipts.append(receipt);restore()
   (out/'mutations.json').write_text(json.dumps(receipts,indent=2)+'\n')
   print(json.dumps(dict(name=name,platform=platform,killed=receipt['killed'],totals=receipt['totals'])),flush=True)
   if not receipt['killed']:raise RuntimeError('inconclusive or surviving mutation: '+name+platform)
   if mode=='doors':
    code,control=run(name+'-restored-'+platform,commands)
    control.update(sourceSha256={n:hashof(original[n]) for n in mutant},cleanCompileAndTest=True)
    (out/(name+'-restored-'+platform+'.json')).write_text(json.dumps(control,indent=2)+'\n')
    assert code==0 and control['totals']
 code,control=run('restored-control',[f'align{p}/testOnly *MappingMeasures* *MappingPresence*' for p in ['JVM','JS','Native']])
 control.update(sourceSha256={n:hashof(v) for n,v in original.items()},cleanCompileAndTest=False)
 (out/'restored-control.json').write_text(json.dumps(control,indent=2)+'\n')
 assert code==0 and control['totals']
finally:restore()
