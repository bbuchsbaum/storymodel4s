#!/usr/bin/env python3
import hashlib,json,re,subprocess,sys
from pathlib import Path
root,out,dep=map(lambda s:Path(s).resolve(),sys.argv[1:4]);mode=sys.argv[4]
out.mkdir(parents=True,exist_ok=True)
path=root/'align/src/main/scala/storymodel4s/align/mapping.scala';original=path.read_text()
hashof=lambda s:hashlib.sha256(s.encode()).hexdigest()
def edit(*changes):
 value=original
 for old,new in changes:
  assert value.count(old)==1,(old,value.count(old));value=value.replace(old,new)
 return value
runtime=[
 ('decoded-argmax-conflation',edit(('case Some(value) => DecodedMass.InCandidateSupport.derived(value)','case Some(value) => DecodedMass.InCandidateSupport.derived(argmax.map(_._2).getOrElse(value))')),"p3 keeps e7's value"),
 ('outside-as-inside-zero',edit(('case None        => DecodedMass.OutsideCandidateSupport.derived()','case None        => DecodedMass.InCandidateSupport.derived(0.0)')),'fill is OutsideCandidateSupport'),
 ('zero-as-outside',edit(('values.get(destination) match','values.get(destination).filter(_ != 0.0) match'),('if values.contains(destination) then','if values.get(destination).exists(_ != 0.0) then')),'in-support zero stays'),
 ('link-union-as-basis',edit(('if values.contains(destination) then','if links.exists(_.destination == destination) then')),'listed fill target is still GapFill'),
 ('agreeing-decode-as-argmax',edit(('if values.contains(destination) then DecisionOrigin.StructuredDecode(p)','if argmax.exists(_._1 == destination) then DecisionOrigin.RawArgmax\n                      else if values.contains(destination) then DecisionOrigin.StructuredDecode(p)')),'agreeing decode stays StructuredDecode'),
 ('unranked-nonlocalizable',edit(('case Destination.External(ExternalState.Unranked) => LocalizationStatus.Unranked','case Destination.External(ExternalState.Unranked) => LocalizationStatus.Nonlocalizable')),'unranked stays'),
 ('insertion-order-ties',edit(('if a._2 == b._2 then a._1.key < b._1.key','if a._2 == b._2 then false')),'p7 tie by key, both kept'),
 ('empty-basis-fallback',edit(('val argmax = values.toVector.sortWith','val argmax = (if values.isEmpty then measures.raw.flatMap(_.values).toMap else values).toVector.sortWith'),('case _ if values.isEmpty =>','case _ if values.isEmpty && measures.destinations.isEmpty =>')),'empty basis is Abstention, NoDecision, Unranked'),
 ('abstain-ignored',edit(('case DecisionRequest.Abstain(_, reason) =>','case DecisionRequest.Abstain(_, reason) if false =>')),'Abstain yields NoDecision, NotComputed'),
 ('external-located',edit(('case Destination.External(_) => LocalizationStatus.Nonlocalizable','case Destination.External(_) => LocalizationStatus.Located')),'external choice Nonlocalizable'),
 ('link-inventory-unchecked',edit(('else if destinations.distinct.size != destinations.size || destinations.toSet != measures.destinations','else if (destinations.distinct.size != destinations.size || destinations.toSet != measures.destinations) && false')),'links equal measured alternatives'),
 ('candidate-id-unchecked',edit(('if links.exists(_.candidateSet != candidateSet) then','if links.exists(_.candidateSet != candidateSet) && false then')),'forged candidate-set id refuses'),
 ('raw-origin-unchecked',edit(('val foreignRaw = measures.raw.exists(r => foreign(r.derivation))','val foreignRaw = measures.raw.exists(r => foreign(r.derivation)) && false')),'unequal derived raw rows with identical candidate keys cannot move'),
 ('posterior-origin-unchecked',edit(('val foreignPosterior = measures.posterior.exists(_.unit != unit)','val foreignPosterior = measures.posterior.exists(_.unit != unit) && false')),'unequal derived posterior rows with identical candidate keys cannot move'),
 ('link-origin-unchecked',edit(('val foreignLink = links.exists(l => foreign(l.derivation))','val foreignLink = links.exists(l => foreign(l.derivation)) && false')),'derived links cannot move between units'),
 ('lower-direction-reversed',edit(('case ScoreDirection.LowerIsBetter  => a._2 < b._2','case ScoreDirection.LowerIsBetter  => a._2 > b._2')),'raw direction is respected'),
 ('abstention-policy-dropped',edit(('case DecisionRequest.Abstain(p, _)        => Some(p)','case DecisionRequest.Abstain(_, _)        => None')),'Abstain yields NoDecision, NotComputed'),
 ('stage-refs-dropped',edit(('Some(stages)','None')),'Abstain yields NoDecision, NotComputed'),
 ('link-stage-unchecked',edit(('else if links.exists(_.inferenceStage != stages.inference) then','else if links.exists(_.inferenceStage != stages.inference) && false then')),'links retain the declared inference stage'),
 ('empty-abstention-accepted',edit(('case DecisionRequest.Abstain(_, reason) if reason.trim.isEmpty =>','case DecisionRequest.Abstain(_, reason) if reason.trim.isEmpty && false =>')),'empty abstention reason refuses')]
runtime.append(('request-retention-dropped',edit(('                policy,\n                request\n', '                policy,\n                DecisionRequest.RawArgmax\n')),'the original decision request survives empty and nonempty rows for replay'))
doors=[('package-construction-doors',original.replace(' private (',' private[align] (').replace('private[UnitOutcome]','private[align]'),[
 'outcomes have no unchecked construction','decisions have no unchecked construction','calibrated decisions have no door','decision basis requires checked construction','decoded mass components have no caller construction','calibration status has no caller construction'])]
mutations=doors if mode=='doors' else runtime
if len(sys.argv)>5:mutations=mutations[int(sys.argv[5])-1:]
base=['sbt','-batch','-Dsbt.global.staging=/private/tmp/storymodel4s-m1-sbt-staging-20260922',f'-Dstorymodel4s.grakern.build={dep}']
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py';receipts=[]
def run(name,commands):
 log=out/(name+'.log');command=[sys.executable,wrapper,'--log',str(log),'--timeout','2400','--',*base,*commands]
 cp=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.wrapper.txt')).write_text(cp.stdout)
 text=log.read_text();return cp.returncode,dict(metadata=json.loads(Path(str(log)+'.meta.json').read_text()),logSha256=hashlib.sha256(log.read_bytes()).hexdigest(),totals=re.findall(r'^.*(?:Passed|Failed): Total.*$',text,re.M),failures=[line for line in text.splitlines() if '==> X' in line])
try:
 for name,mutant,expected in mutations:
  expected=[expected] if isinstance(expected,str) else expected
  for platform in (['JVM','JS','Native'] if mode=='doors' else ['JVM']):
   path.write_text(mutant);project='align'+platform
   commands=[f'{project}/Compile/clean',f'{project}/Test/clean'] if mode=='doors' else []
   pattern='*MappingOutcomeUnforgeableSuite *MappingOutcomePackageAttackSuite' if mode=='doors' else '*MappingOutcomeSuite'
   commands.append(f'{project}/testOnly {pattern}')
   code,receipt=run(name+'-'+platform,commands)
   receipt.update(name=name,platform=platform,sourceSha256=hashof(original),mutantSha256=hashof(mutant),command=commands,cleanCompileAndTest=mode=='doors',expectedFailures=expected)
   receipt['killed']=code!=0 and bool(receipt['totals']) and all(e in '\n'.join(receipt['failures']) for e in expected)
   receipts.append(receipt);path.write_text(original);(out/'mutations.json').write_text(json.dumps(receipts,indent=2)+'\n')
   print(json.dumps(dict(name=name,platform=platform,killed=receipt['killed'],totals=receipt['totals'])),flush=True)
   if not receipt['killed']:raise RuntimeError('inconclusive or surviving mutation: '+name+platform)
   if mode=='doors':
    code,control=run(name+'-restored-'+platform,commands);control.update(sourceSha256=hashof(original),cleanCompileAndTest=True)
    (out/(name+'-restored-'+platform+'.json')).write_text(json.dumps(control,indent=2)+'\n');assert code==0 and control['totals']
 code,control=run('restored-control',[f'align{p}/testOnly *MappingOutcome*' for p in ['JVM','JS','Native']]);control.update(sourceSha256=hashof(original),cleanCompileAndTest=False)
 (out/'restored-control.json').write_text(json.dumps(control,indent=2)+'\n');assert code==0 and control['totals']
finally:path.write_text(original)
