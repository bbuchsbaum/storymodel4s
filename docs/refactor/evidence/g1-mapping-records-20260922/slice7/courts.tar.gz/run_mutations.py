#!/usr/bin/env python3
import hashlib,json,re,subprocess,sys
from pathlib import Path
root,out,dep=map(lambda s:Path(s).resolve(),sys.argv[1:4]);mode=sys.argv[4]
out.mkdir(parents=True,exist_ok=True)
path=root/'align/src/main/scala/storymodel4s/align/mappingresult.scala';original=path.read_text()
hashof=lambda s:hashlib.sha256(s.encode()).hexdigest()
def edit(*changes):
 value=original
 for old,new in changes:
  assert value.count(old)==1,(old,value.count(old));value=value.replace(old,new)
 return value
runtime=[
 ('missing-unit-accepted',edit(('outcomes.map(_.unit) == inventory.units.map(_.id)', 'outcomes.map(_.unit).forall(inventory.units.map(_.id).contains)')), 'missing unit refuses'),
 ('outcome-order-ignored',edit(('outcomes.map(_.unit) == inventory.units.map(_.id)', 'outcomes.map(_.unit).toSet == inventory.units.map(_.id).toSet')), 'reordered outcomes refuse'),
 ('failed-outcomes-filtered',edit(('      outcomes\n    )', '      outcomes.filter(_.processing == ProcessingStatus.Complete)\n    )')), 'failed outcomes are retained and counted'),
 ('unknown-target-accepted',edit(('unknown.toLeft(()).left.map(MappingRefusal.UnknownTarget(_))', 'unknown.filter(_ => false).toLeft(()).left.map(MappingRefusal.UnknownTarget(_))')), 'universe outside dictionary refuses'),
 ('universe-subset-unchecked',edit(('!wrongGrain && mentioned.forall(universe)', '!wrongGrain && mentioned.forall(_ => true)')), 'measured targets outside the declared universe refuse while externals are exempt'),
 ('target-grain-unchecked',edit(('!wrongGrain && mentioned.forall(universe)', '(!wrongGrain || true) && mentioned.forall(universe)')), 'the target universe agrees with actual target levels'),
 ('roles-unchecked',edit(('Either.cond(!wrongRoles,', 'Either.cond(!wrongRoles || true,')), 'roles are bound to the inventory segmentation'),
 ('normalized-universe-unchecked',edit(('normalized.forall(_.universe == policies.universe.id)', 'normalized.forall(_ => true)')), 'normalized mass matches universe and prior'),
 ('normalized-prior-unchecked',edit(('Either.cond(!wrongPrior,', 'Either.cond(!wrongPrior || true,')), 'normalized mass matches universe and prior'),
 ('measure-stage-unchecked',edit(('.traverse_(stageExists)', '.filter(_ => false).traverse_(stageExists)')), 'unknown stage entry refuses'),
 ('outcome-stage-unchecked',edit(('outcome.stages.traverse_', 'outcome.stages.filter(_ => false).traverse_')), 'empty computed rows retain and validate their stage references'),
 ('scope-refusal-skipped',edit(('scopeFailures.headOption.toLeft(())', 'scopeFailures.filter(_ => false).headOption.toLeft(())')), 'Assessed on a non-Declared target refuses'),
 ('multiple-bindings-accepted',edit(('bindings.size <= 1', 'bindings.size <= 1 || true')), 'record mixing two results refuses'),
 ('inventory-binding-unchecked',edit(('binding.inventoryDigest != inventory.digest then', 'binding.inventoryDigest != inventory.digest && false then')), 'foreign inventory binding refuses even when unit ids and segmentation match'),
 ('source-binding-unchecked',edit(('binding.viewFingerprint != source.viewFingerprint then', 'binding.viewFingerprint != source.viewFingerprint && false then')), 'bound values refuse a different source fingerprint'),
 ('scope-binding-unchecked',edit(('binding.scopeDigest != source.scopeDigest then', 'binding.scopeDigest != source.scopeDigest && false then')), 'bound values refuse a different source scope'),
 ('truncation-demoted',edit(('      policies,\n', '      MappingPolicies.of(policies.inference, policies.context, CandidatePolicy.Unknown("demoted"), policies.referencePrior, policies.decision, policies.universe).toOption.get,\n')), 'Truncated(8) is retained'),
 ('request-identity-dropped',edit(('request(value.request)', 'request(DecisionRequest.RawArgmax)')), 'record digest distinguishes values, failure reasons and request identity')]
doors=[('package-construction-doors',original.replace(' private (',' private[align] (').replace('private[MappingResult]','private[align]'),['result has no unchecked construction','bound derivation is owner constructed'])]
mutations=doors if mode=='doors' else runtime
if len(sys.argv)>5:mutations=mutations[int(sys.argv[5])-1:]
base=['sbt','-batch','-Dsbt.global.staging=/private/tmp/storymodel4s-m1-sbt-staging-20260922',f'-Dstorymodel4s.grakern.build={dep}']
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py';receipts=[]
def run(name,commands):
 log=out/(name+'.log');command=[sys.executable,wrapper,'--log',str(log),'--timeout','2400','--',*base,*commands]
 cp=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.wrapper.txt')).write_text(cp.stdout)
 text=log.read_text();return cp.returncode,dict(metadata=json.loads(Path(str(log)+'.meta.json').read_text()),logSha256=hashlib.sha256(log.read_bytes()).hexdigest(),totals=re.findall(r'^.*(?:Passed|Failed): Total.*$',text,re.M),failures=[line for line in text.splitlines() if '==> X' in line])
try:
 for name,mutant,expected in mutations:
  expected=[expected] if isinstance(expected,str) else expected
  for platform in (['JVM','JS','Native'] if mode=='doors' else ['JVM']):
   path.write_text(mutant);project='align'+platform
   commands=[f'{project}/Compile/clean',f'{project}/Test/clean'] if mode=='doors' else []
   pattern='*MappingResultUnforgeableSuite *MappingResultPackageAttackSuite' if mode=='doors' else '*MappingResultSuite'
   commands.append(f'{project}/testOnly {pattern}')
   code,receipt=run(name+'-'+platform,commands)
   receipt.update(name=name,platform=platform,sourceSha256=hashof(original),mutantSha256=hashof(mutant),command=commands,cleanCompileAndTest=mode=='doors',expectedFailures=expected)
   receipt['killed']=code!=0 and bool(receipt['totals']) and all(e in '\n'.join(receipt['failures']) for e in expected)
   receipts.append(receipt);path.write_text(original);(out/'mutations.json').write_text(json.dumps(receipts,indent=2)+'\n')
   print(json.dumps(dict(name=name,platform=platform,killed=receipt['killed'],totals=receipt['totals'])),flush=True)
   if not receipt['killed']:raise RuntimeError('inconclusive or surviving mutation: '+name+platform)
   if mode=='doors':
    code,control=run(name+'-restored-'+platform,commands);control.update(sourceSha256=hashof(original),cleanCompileAndTest=True)
    (out/(name+'-restored-'+platform+'.json')).write_text(json.dumps(control,indent=2)+'\n');assert code==0 and control['totals']
 code,control=run('restored-control',[cmd for p in ['JVM','JS','Native'] for cmd in [f'align{p}/testOnly *MappingResult*', f'laws{p}/testOnly *MappingContractSuite']]);control.update(sourceSha256=hashof(original),cleanCompileAndTest=False)
 (out/'restored-control.json').write_text(json.dumps(control,indent=2)+'\n');assert code==0 and control['totals']
finally:path.write_text(original)
