from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path('/private/tmp/storymodel4s-workspace-m1-20260922');out=Path('/private/tmp/workspace-m1-evidence/g1/slice10-snapshot-mutation');out.mkdir(parents=True,exist_ok=True)
p=root/'codec/src/main/scala/storymodel4s/codec/mapping.scala';source=p.read_text();old='captured = inputs.copy(view = capture(inputs.view))';assert source.count(old)==1;mutant=source.replace(old,'captured = inputs.copy(view = inputs.view)')
base=['sbt','-batch','-Dsbt.global.staging=/private/tmp/storymodel4s-m1-sbt-staging-20260922','-Dstorymodel4s.grakern.build=/private/tmp/storymodel4s-m1-grakern-20260922']
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py'
def run(name):
 log=out/(name+'.log');cmd=[sys.executable,wrapper,'--log',str(log),'--timeout','1200','--',*base,'codecJVM/testOnly *MappingCodecSuite']
 cp=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.wrapper.txt')).write_text(cp.stdout);txt=log.read_text()
 return dict(metadata=json.loads(Path(str(log)+'.meta.json').read_text()),logSha256=hashlib.sha256(log.read_bytes()).hexdigest(),totals=re.findall(r'^.*(?:Passed|Failed): Total.*$',txt,re.M),failures=[l for l in txt.splitlines() if '==> X' in l])
try:
 p.write_text(mutant);r=run('context-reread');r.update(sourceSha256=hashlib.sha256(source.encode()).hexdigest(),mutantSha256=hashlib.sha256(mutant.encode()).hexdigest(),name='context-reread',path=str(p.relative_to(root)),expectedFailure='decoded mapping owns its snapshot after mutable context changes');r['killed']=r['metadata']['exit_code']!=0 and bool(r['totals']) and r['expectedFailure'] in '\n'.join(r['failures']);(out/'mutation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);assert r['killed']
finally:p.write_text(source)
c=run('restored-control');(out/'restored-control.json').write_text(json.dumps(c,indent=2)+'\n');assert c['metadata']['exit_code']==0 and c['totals']==['[info] Passed: Total 32, Failed 0, Errors 0, Passed 32'];print('restored control: 32 passed',flush=True)
