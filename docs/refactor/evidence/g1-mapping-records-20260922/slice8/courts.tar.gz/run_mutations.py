#!/usr/bin/env python3
import hashlib,json,re,subprocess,sys
from pathlib import Path
root,out,dep=map(lambda s:Path(s).resolve(),sys.argv[1:4])
out.mkdir(parents=True,exist_ok=True)
path=root/'align/src/main/scala/storymodel4s/align/mappinghistory.scala';original=path.read_text()
binding=root/'align/src/main/scala/storymodel4s/align/mappingbinding.scala';bindingOriginal=binding.read_text()
measures=root/'align/src/main/scala/storymodel4s/align/mappingmeasures.scala';measuresOriginal=measures.read_text()
hashof=lambda s:hashlib.sha256(s.encode()).hexdigest()
def edit(*changes):
 value=original
 for old,new in changes:
  assert value.count(old)==1,(old,value.count(old));value=value.replace(old,new)
 return value
runtime=[
 ('source-only-argmax',path,original,edit(('case HistoricalDecode.ArgmaxOnly         => DecisionRequest.RawArgmax','case HistoricalDecode.ArgmaxOnly => result.posterior.row(unit).flatMap(_.mapSource).fold[DecisionRequest](DecisionRequest.Abstain(policy, "no source"))(ref => DecisionRequest.ExternalDecode(Destination.Target(ref), policy))')), 'Unranked row argmax is external'),
 ('decoded-none-falls-back',path,original,edit(('DecisionRequest.Abstain(policy, "Historical decoder supplied no destination")','DecisionRequest.RawArgmax')), 'Decoded None is Abstention'),
 ('decode-inventory-unchecked',path,original,edit(('if chosen.keySet != units.toSet =>','if chosen.keySet != units.toSet && false =>')), 'decode must account for exactly the requested units'),
 ('invented-historical-receipts',path,original,edit(('StageProvenance.unknown(UnknownProvenanceReason.HistoricalArtifact, None)', 'StageProvenance.unknown(UnknownProvenanceReason.HistoricalArtifact, Some(StageReceipt.of(stage, "invented", storymodel4s.core.Checksum.ofText("invented"), Vector.empty, ProviderStatus.NotApplicable("invented")).toOption.get))')), 'historical ledger asserts no receipts'),
 ('missing-cost-defaulted',path,original,edit(('              candidates\n            )','              candidates\n            ).orElse(Right(MappingLink.ungated(Destination.of(state), stages, candidates)))')), 'missing breakdown refuses'),
 ('view-reread',path,original,edit(('val checkedView = MappingBindingRender.snapshot(view)','val checkedView = view')), 'adapter captures a changing view once for binding and all link assessment'),
 ('basis-changed-to-cost',path,original,edit(('DecisionBasis.of(MeasureKind.ModelPosterior, None)', 'DecisionBasis.of(MeasureKind.RawScore, Some("hsmm.local-cost"))')), 'historical posterior is bit-equal to the supplied result'),
 ('supplied-source-rebound',path,original,edit(('      source: SourceRepresentation,','      suppliedSource: SourceRepresentation,'),('val checkedView = MappingBindingRender.snapshot(view)','val checkedView = MappingBindingRender.snapshot(view)\n    val source = SourceRepresentation.of(checkedView, suppliedSource.bundles, suppliedSource.composition, suppliedSource.targets.map(t => t.ref -> t.sourceSupport).toMap).toOption.get')), 'source from another view refuses'),
 ('recall-binding-checks-bypassed',binding,bindingOriginal,bindingOriginal.replace('if result.recallChecksum != AlignWire.recallChecksum(recall) then','if result.recallChecksum != AlignWire.recallChecksum(recall) && false then').replace('if AlignWire.recallChecksum(recall) != recallChecksum then','if AlignWire.recallChecksum(recall) != recallChecksum && false then'), 'foreign recall with shared unit IDs refuses'),
 ('external-as-assessed',measures,measuresOriginal,measuresOriginal.replace('TermSupport.Evaluated.derived(SupportAssessment.externalState)','TermSupport.Evaluated.derived(result.costs(unit).values.find(_.support.isInstanceOf[SupportAssessment.Assessed]).get.support)'), 'external links remain NotApplicable')]
if len(sys.argv)>4:runtime=runtime[int(sys.argv[4])-1:]
base=['sbt','-batch','-Dsbt.global.staging=/private/tmp/storymodel4s-m1-sbt-staging-20260922',f'-Dstorymodel4s.grakern.build={dep}']
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py';receipts=[]
def run(name,commands):
 log=out/(name+'.log');command=[sys.executable,wrapper,'--log',str(log),'--timeout','2400','--',*base,*commands]
 cp=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.wrapper.txt')).write_text(cp.stdout)
 text=log.read_text();return cp.returncode,dict(metadata=json.loads(Path(str(log)+'.meta.json').read_text()),logSha256=hashlib.sha256(log.read_bytes()).hexdigest(),totals=re.findall(r'^.*(?:Passed|Failed): Total.*$',text,re.M),failures=[line for line in text.splitlines() if '==> X' in line])
try:
 for name,changed,source,mutant,expected in runtime:
  assert source != mutant,name
  changed.write_text(mutant)
  code,receipt=run(name,['alignJVM/testOnly *MappingHistoricalSuite'])
  receipt.update(name=name,platform='JVM',path=str(changed.relative_to(root)),sourceSha256=hashof(source),mutantSha256=hashof(mutant),expectedFailures=[expected])
  receipt['killed']=code!=0 and bool(receipt['totals']) and expected in '\n'.join(receipt['failures'])
  receipts.append(receipt);changed.write_text(source);(out/'mutations.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(json.dumps(dict(name=name,killed=receipt['killed'],totals=receipt['totals'])),flush=True)
  if not receipt['killed']:raise RuntimeError('inconclusive or surviving mutation: '+name)
 code,control=run('restored-control',[f'align{p}/testOnly *MappingHistoricalSuite' for p in ['JVM','JS','Native']]);control.update(sourceSha256=hashof(original))
 (out/'restored-control.json').write_text(json.dumps(control,indent=2)+'\n');assert code==0 and control['totals']
finally:
 path.write_text(original);binding.write_text(bindingOriginal);measures.write_text(measuresOriginal)
