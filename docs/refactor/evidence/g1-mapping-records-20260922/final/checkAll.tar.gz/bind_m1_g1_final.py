#!/usr/bin/env python3
"""Bind the completed G1 full gate; refuse partial or unbound evidence."""
from pathlib import Path
import datetime, hashlib, json, re, subprocess, tarfile, xml.etree.ElementTree as ET
root=Path('/private/tmp/storymodel4s-workspace-m1-20260922')
raw=Path('/private/tmp/workspace-m1-evidence/g1')
log=raw/'slice10-checkAll-a4ad2e06.log'
out=raw/'final';out.mkdir(exist_ok=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert sha=='a4ad2e06123dcca61f4494a39fb4aaef832bff94',sha
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True).strip()
meta=json.loads(Path(str(log)+'.meta.json').read_text())
assert meta['exit_code']==0 and meta['reason']=='exited' and meta['command'][-1]=='checkAll',meta
text=log.read_text();build=(root/'build.sbt').read_text()
def items(name):
 return re.findall(r'"([A-Za-z]+)"',re.search(r'val '+name+r' = List\((.*?)\)',build,re.S)[1])
tasks=[m+p+'/test' for m in items('allModules') for p in items('allPlatforms')]+[m+'/test' for m in items('jvmOnlyModules')]
lines=re.findall(r'^.*(?:Passed|Failed): Total \d+.*$',text,re.M)
assert len(tasks)==len(lines),(len(tasks),len(lines))
counts={k:0 for k in ['Total','Passed','Failed','Errors','Skipped','Ignored']};bound=[]
for task,line in zip(tasks,lines):
 row={k:int(re.search(r'\b'+k+r' (\d+)',line)[1]) if re.search(r'\b'+k+r' (\d+)',line) else 0 for k in counts}
 assert row['Failed']==row['Errors']==0 and row['Total']>0,(task,row)
 for k in counts:counts[k]+=row[k]
 bound.append(dict(task=task,counts=row,summary=line))
assert not re.search(r'\[error\]|==> X',text)
start=datetime.datetime.fromisoformat(meta['started_utc']).timestamp()
reports=[];skips=[]
for p in sorted(root.glob('**/test-reports/*.xml')):
 t=ET.parse(p).getroot()
 reports.append(dict(path=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),fresh=p.stat().st_mtime>=start))
 for case in t.iter('testcase'):
  for s in case.findall('skipped'):
   skips.append(dict(suite=case.get('classname'),test=case.get('name'),reason=s.get('message','')))
assert all(r['fresh'] for r in reports),[r['path'] for r in reports if not r['fresh']]
assert len(skips)==counts['Skipped'],(len(skips),counts)
archive=out/'checkAll.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 tar.add(log,arcname='gate.log');tar.add(Path(str(log)+'.meta.json'),arcname='command.json')
 for r in reports:tar.add(root/r['path'],arcname=r['path'])
 tar.add(Path(__file__),arcname='bind_m1_g1_final.py')
receipt=dict(schema='storymodel4s.g1-final-gate/v1',source=sha,mergeBase='5f39c3580d998c466b85dec72cbded9a0171abda',cleanTrackedAndUntrackedTree=True,commandReceipt=meta,logSha256=hashlib.sha256(log.read_bytes()).hexdigest(),tasks=bound,counts=counts,skips=skips,warnings=[line for line in text.splitlines() if '[warn]' in line or "upgrade to clang" in line],junit=reports,archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(out/'checkAll.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(source=sha,tasks=len(bound),counts=counts,skips=skips,warningLines=len(receipt['warnings']),reports=len(reports)),indent=2))
