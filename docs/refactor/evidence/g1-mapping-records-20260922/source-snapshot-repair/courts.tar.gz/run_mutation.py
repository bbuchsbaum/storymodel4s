import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path('/private/tmp/storymodel4s-workspace-m1-20260922');out=Path('/private/tmp/workspace-m1-evidence/g1');path=root/'align/src/main/scala/storymodel4s/align/mappingsource.scala'
original=path.read_text();old='ViewFingerprint.of(checkedView)';assert original.count(old)==1;mutant=original.replace(old,'ViewFingerprint.of(view)')
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py'
base=['sbt','-batch','-Dsbt.global.staging=/private/tmp/storymodel4s-m1-sbt-staging-20260922','-Dstorymodel4s.grakern.build=/private/tmp/storymodel4s-m1-grakern-20260922','alignJVM/testOnly *SourceRepresentationSnapshotSuite']
receipts=[]
try:
 for name,source,expected in [('mutant',mutant,False),('restored',original,True)]:
  path.write_text(source);log=out/('source-snapshot-'+name+'.log')
  cp=subprocess.run([sys.executable,wrapper,'--log',str(log),'--timeout','1200','--',*base],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (out/('source-snapshot-'+name+'.wrapper.txt')).write_text(cp.stdout);text=log.read_text()
  r={'name':name,'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'metadata':json.loads(Path(str(log)+'.meta.json').read_text()),'totals':re.findall(r'^.*(?:Passed|Failed): Total.*$',text,re.M),'failures':[l for l in text.splitlines() if '==> X' in l]};receipts.append(r)
  if expected:assert cp.returncode==0 and any('Total 2, Failed 0, Errors 0, Passed 2' in l for l in r['totals'])
  else:
   assert cp.returncode!=0 and any('Total 2, Failed 2, Errors 0, Passed 0' in l for l in r['totals'])
   assert all(t in '\n'.join(r['failures']) for t in ['source targets and fingerprint use one captured inventory','a changing source cannot bind a second inventory with different levels'])
finally:
 path.write_text(original);(out/'source-snapshot-mutation.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2))
