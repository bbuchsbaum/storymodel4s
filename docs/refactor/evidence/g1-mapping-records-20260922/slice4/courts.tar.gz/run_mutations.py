#!/usr/bin/env python3
"""Sequential, restoring support-boundary mutations; raw sbt output is retained."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
dependency = Path(sys.argv[3]).resolve()
out.mkdir(parents=True, exist_ok=True)
source = root / "align/src/main/scala/storymodel4s/align/mappingsource.scala"
original = source.read_text()
digest = lambda b: hashlib.sha256(b).hexdigest()
wrapper = "/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py"
base = ["sbt", "-batch", f"-Dstorymodel4s.grakern.build={dependency}"]
receipts = []
def once(old,new):
    assert original.count(old) == 1, (old,original.count(old))
    return original.replace(old,new)
def edits(*pairs):
    value = original
    for old,new in pairs:
        assert value.count(old) == 1, (old,value.count(old))
        value=value.replace(old,new)
    return value
mutations = [
 ("foreign-axis-admitted",once('case Vector()          => Left(MappingRefusal.ForeignAxis(axis))','case Vector()          => Right(axis -> BundleRole.Part(bundle.id))'),"axis outside inventory refuses",False),
 ("ambiguous-first-match",edits(
   ('else if duplicateAxes.nonEmpty then','else if duplicateAxes.nonEmpty && false then'),
   ('available.filter(_.identity == support.bundleIdentity) match','available.filter(_.identity == support.bundleIdentity).take(1) match'),
   ('axisRoles.filter(_._1 == axis) match','axisRoles.filter(_._1 == axis).take(1) match')),"ambiguous axis refuses",False),
 ("anchor-bundle-used-as-part",once('case Vector((_, role)) => Right(axis -> role)','case Vector((_, _)) => Right(axis -> BundleRole.Part(bundle.id))'),"Sherlock-shaped rows resolve to part bundles",False),
 ("composition-coverage-skipped",once('if !coverage || !streamsMatch || !extentsMatch then','if (coverage && false) || !streamsMatch || !extentsMatch then'),"composition covers exactly its parts",False),
 ("composition-recheck-skipped",once('_ <- checkedComposition','_ <- checkedComposition.orElse(Right(()))'),"composition over an unlisted part refuses",False),
 ("cross-part-admitted",once('if nativeParts.size > 1 && composition.isEmpty then','if nativeParts.size > 1 && composition.isEmpty && false then'),"cross-part target refuses without composition",False),
 ("part-id-implies-order",once('if left.isEmpty || right.isEmpty then PartOrder.Incomparable','if left.isEmpty || right.isEmpty then (if a.value < b.value then PartOrder.Before else PartOrder.After)'),"e2 to e7 Incomparable without declaration and Before under composition",False),
 ("duplicate-target-admitted",once('if duplicateRefs.nonEmpty then','if duplicateRefs.nonEmpty && false then'),"duplicate target ref refuses",False),
 ("missing-child-fabricated-covered",once('children.filter(r => physical(r).isInstanceOf[SourceSupportStatus.Unlocated])','children.filter(r => physical(r).isInstanceOf[SourceSupportStatus.Unlocated] && false)'),"g1 is Partial and does not fabricate e4 support",False),
 ("unlocated-leaf-complete",once('else Unknown.derived()','else Complete.derived()'),"unlocated leaf is Unknown",False),
 ("view-order-digest",edits(
  ('targets.sortBy(_.ref.key).map(MappingSourceRender.target)','targets.map(MappingSourceRender.target)'),
  ('targets <- nodes.sortBy(_.ref.key).traverse','targets <- nodes.traverse')),"permuted view has same digest",False),
 ("scope-digest-omitted",once('MappingSourceRender.scope(nodes)','MappingRender.digest(Vector("scope-omitted"))'),"Declared twin changes scopeDigest",False),
 ("legacy-bundle-id-collapses-parts",edits(
  ('else if ambiguousBundleIds.nonEmpty then', 'else if ambiguousBundleIds.nonEmpty && false then'),
  ('val nativeParts = entries.collect { case (axis, BundleRole.Part(_)) =>\n                            axis', 'val nativeParts = entries.collect { case (_, BundleRole.Part(id)) =>\n                            id')),"distinct parts sharing a legacy bundle ID refuse",False)
]

def run(name, commands):
    log = out / f"{name}.log"
    command = [sys.executable, wrapper, "--log", str(log), "--timeout", "1800", "--", *base, *commands]
    completed = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out / f"{name}.wrapper.txt").write_text(completed.stdout)
    text = log.read_text()
    metadata = json.loads(Path(str(log) + ".meta.json").read_text())
    return completed.returncode, text, dict(metadata=metadata, logSha256=digest(log.read_bytes()),
        totals=re.findall(r"^.*(?:Passed|Failed): Total.*$", text, re.M),
        failures=[line for line in text.splitlines() if "==> X" in line])

try:
    for name, mutant, expected, compile_door in mutations:
        platforms = ["JVM", "JS", "Native"] if compile_door else ["JVM"]
        for platform in platforms:
            source.write_text(mutant)
            project = "align" + platform
            commands = [f"{project}/Compile/clean", f"{project}/Test/clean"] if compile_door else []
            commands.append(f"{project}/testOnly *SourceRepresentation*")
            code, text, receipt = run(name+"-"+platform,commands)
            receipt.update(name=name,platform=platform,sourceSha256=digest(original.encode()),mutantSha256=digest(mutant.encode()),command=commands,cleanCompileAndTest=compile_door,expectedFailure=expected)
            receipt["killed"]=code != 0 and bool(receipt["totals"]) and expected in "\n".join(receipt["failures"])
            receipts.append(receipt)
            source.write_text(original)
            (out/"mutations.json").write_text(json.dumps(receipts,indent=2)+"\n")
            print(json.dumps(dict(name=name,platform=platform,killed=receipt["killed"],totals=receipt["totals"])),flush=True)
            if not receipt["killed"]: raise RuntimeError("inconclusive or surviving mutation: "+name+platform)
            if compile_door:
                code,text,control=run(name+"-restored-"+platform,commands)
                control.update(sourceSha256=digest(source.read_bytes()),cleanCompileAndTest=True)
                (out/(name+"-restored-"+platform+".json")).write_text(json.dumps(control,indent=2)+"\n")
                assert code == 0 and control["totals"]
    code,text,control=run("restored-control",["alignJVM/testOnly *SourceRepresentation*","alignJS/testOnly *SourceRepresentation*","alignNative/testOnly *SourceRepresentation*"])
    control.update(sourceSha256=digest(source.read_bytes()),cleanCompileAndTest=False)
    (out/"restored-control.json").write_text(json.dumps(control,indent=2)+"\n")
    assert code == 0 and control["totals"]
finally:
    source.write_text(original)
