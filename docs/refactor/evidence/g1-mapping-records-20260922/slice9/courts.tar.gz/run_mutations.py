#!/usr/bin/env python3
import hashlib,json,re,subprocess,sys
from pathlib import Path
root,out,dep=map(lambda s:Path(s).resolve(),sys.argv[1:4]);out.mkdir(parents=True,exist_ok=True)
prefix=Path('codec/src/main/scala/storymodel4s/codec')
files={n:root/prefix/(n+'.scala') for n in ['mapping','mappingjson','mappingmetadataread','mappingrecordwire','mappingoutcomeread','mappingsourcewire']}
originals={n:p.read_text() for n,p in files.items()}
hashof=lambda s:hashlib.sha256(s.encode()).hexdigest()
def edit(file,*pairs):
 s=originals[file]
 for old,new in pairs:
  assert s.count(old)==1,(file,old,s.count(old));s=s.replace(old,new)
 return s
mutations=[]
def add(name,file,expected,*pairs): mutations.append((name,file,edit(file,*pairs),expected))
add('numeric-coordinate-encoding','mappingjson','ticks and rational denominator above 2^53 remain exact strings',('def long(value: Long): Json = str(value.toString)','def long(value: Long): Json = Json.fromLong(value)'))
add('numeric-coordinate-admission','mappingjson','numeric tick refuses with NumericTick',('if value.isNumber then Left(MappingCodecError.NumericTick(path))','if value.isNumber then Right(value.asNumber.get.toLong.get)'))
add('derived-demoted','mappingmetadataread','derived refuses with Reserved',('case "derived" => Left(MappingCodecError.Reserved("derived"))','case "derived" => Right(StageProvenance.unknown(UnknownProvenanceReason.HistoricalArtifact,None))'))
add('calibration-reserved-check-bypassed','mapping','calibrated refuses with Reserved',('key == "status" && child.asString.contains("calibrated")','key == "status" && child.asString.contains("calibrated") && false'))
add('unknown-reason-demoted','mappingmetadataread','historical text round-trips identically',('yield StageProvenance.unknown(reason, asserted)','yield StageProvenance.unknown(if reason == UnknownProvenanceReason.HistoricalArtifact then UnknownProvenanceReason.NotRun else reason, asserted)'))
add('asserted-receipt-dropped','mappingmetadataread','caller asserted receipt remains Unknown and round-trips exactly',('yield StageProvenance.unknown(reason, asserted)','yield StageProvenance.unknown(reason, asserted.filter(_ => false))'))
add('rounded-value-encoding','mappingjson','historical canonical bytes and record identity are pinned',('str(CanonicalDouble.render(value))','str(CanonicalDouble.render(math.rint(value * 1e6) / 1e6))'))
add('term-support-requirement-skipped','mappingoutcomeread','missing term_support refuses',('_ <- field[Json](value, "term_support")','_ <- Right(value)'))
add('not-computed-omitted','mappingrecordwire','not-computed is encoded explicitly and only equals ungated evidence',('  )\n  def metadata(value: UnitMeasures): Json = obj(','  ).mapObject(o => if value.termSupport.isInstanceOf[TermSupportStatus.NotComputed] then o.remove("term_support") else o)\n  def metadata(value: UnitMeasures): Json = obj('))
add('not-computed-on-gated-link','mappingrecordwire','not-computed is encoded explicitly and only equals ungated evidence',('tagged("evaluated", "assessment" -> SupportAssessmentWire.encode(v.assessment))','if v.assessment != null then tagged("not-computed", "reason" -> str("NoCostBreakdown")) else tagged("evaluated", "assessment" -> SupportAssessmentWire.encode(v.assessment))'))
add('binding-fields-unchecked','mappingmetadataread','each unmixed result needs its own context',('Json.fromString(actual) == v','Json.fromString(actual) == v || true'))
add('recall-checksum-optional','mappingmetadataread','match fields are mandatory',('field[String](value, key).flatMap(actual =>','field[String](value, key).orElse(if key == "recall_checksum" then Right(v.asString.get) else invalid(key,"missing")).flatMap(actual =>'))
add('timebase-absence-null','mappingsourcewire','absent timebase is tagged',('"timebase" -> optional(value.timebase)(v => rational(v.scale)),\n    "fingerprint"','"timebase" -> value.timebase.fold(Json.Null)(v => optional(Some(v))(v => rational(v.scale))),\n    "fingerprint"'))
add('version-check-skipped','mapping','v0.2 refuses with UnsupportedSchema before parsing its body',('version == SchemaVersion,','version == SchemaVersion || true,'))
add('inventory-digest-check-skipped','mapping','foreign inventory refuses with DigestMismatch despite shared unit IDs',('inventoryDigest == context.inventory.digest.hex,','inventoryDigest == context.inventory.digest.hex || true,'))
add('failed-outcomes-filtered','mappingrecordwire','miniature round-trips and retains p6',('array(value.outcomes.map(outcome))','array(value.outcomes.filter(_.processing == ProcessingStatus.Complete).map(outcome))'))
add('canonical-guard-skipped','mapping','unknown field refuses',('print(json) == encode(result),','print(json) == encode(result) || true,'))
add('null-fields-dropped','mappingjson','unknown null fields refuse at the root and inside policies',('dropNullValues = false','dropNullValues = true'))
add('original-request-replaced','mappingoutcomeread','empty external decode and explicit abstention retain their original requests',('UnitOutcome.computed(unit, measures, links, basis, request, stages)','UnitOutcome.computed(unit, measures, links, basis, if request != null then DecisionRequest.RawArgmax else request, stages)'))
add('duplicate-key-check-skipped','mapping','duplicate object keys refuse before parser normalization can erase them',('_ <- uniqueObjectKeys(text)','_ <- Right(text)'))
add('duplicate-key-spelling-not-decoded','mappingjson','duplicate object keys refuse before parser normalization can erase them',('!frame.keys.add(key)','!frame.keys.add(text.substring(start,index))'))
add('duplicate-keys-shared-across-objects','mappingjson','the same key in different nested objects remains legal',('    final class ObjectFrame:\n      val keys = scala.collection.mutable.HashSet.empty[String]','    val shared = scala.collection.mutable.HashSet.empty[String]\n    final class ObjectFrame:\n      val keys = shared'))
base=['sbt','-batch','-Dsbt.global.staging=/private/tmp/storymodel4s-m1-sbt-staging-20260922',f'-Dstorymodel4s.grakern.build={dep}']
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py';receipts=[]
def run(name,commands):
 log=out/(name+'.log');command=[sys.executable,wrapper,'--log',str(log),'--timeout','1200','--',*base,*commands]
 cp=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.wrapper.txt')).write_text(cp.stdout)
 text=log.read_text();return cp.returncode,dict(metadata=json.loads(Path(str(log)+'.meta.json').read_text()),logSha256=hashlib.sha256(log.read_bytes()).hexdigest(),totals=re.findall(r'^.*(?:Passed|Failed): Total.*$',text,re.M),failures=[line for line in text.splitlines() if '==> X' in line])
if len(sys.argv)>4:mutations=mutations[int(sys.argv[4])-1:]
try:
 for name,file,mutant,expected in mutations:
  files[file].write_text(mutant)
  code,receipt=run(name,['codecJVM/testOnly *MappingCodecSuite *MappingCodecDigestSuite'])
  receipt.update(name=name,platform='JVM',path=str(files[file].relative_to(root)),sourceSha256=hashof(originals[file]),mutantSha256=hashof(mutant),expectedFailures=[expected])
  receipt['killed']=code!=0 and bool(receipt['totals']) and expected in '\n'.join(receipt['failures'])
  receipts.append(receipt);files[file].write_text(originals[file]);(out/'mutations.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(json.dumps(dict(name=name,killed=receipt['killed'],totals=receipt['totals'])),flush=True)
  if not receipt['killed']:raise RuntimeError('inconclusive or surviving mutation: '+name)
 code,control=run('restored-control',['codecJVM/testOnly *MappingCodec*Suite *AlignCodecSuite']);(out/'restored-control.json').write_text(json.dumps(control,indent=2)+'\n');assert code==0 and control['totals']
finally:
 for name,path in files.items():path.write_text(originals[name])
