# Temporal-query consumer handoff

Existing consumer: `bd-01M354JNKNKJ15N4T5MGQTRSET`. This is the post-M1
extension described in [workspace-m1.md](workspace-m1.md#post-m1-temporal-analysis-and-uncertainty-inspection),
not an expansion of M1 acceptance.

StoryModel candidate `b8f22d0091f0427f779b86ac5e7e90a828da4070` supplies
`TemporalQuery`, contextual `temporal-query/v0.1`, `TemporalPartitionView` and
declared scanner/sample contracts. See the sibling
[query guide](../../../storymodel4s/docs/temporal-queries.md),
[scanner guide](../../../storymodel4s/docs/scanner-crosswalks.md) and
[qualification](../../../storymodel4s/docs/refactor/evidence/temporal-scanner-20260922/README.md).
Producer qualification passed: 8,079 tests, five optional live skips, zero failures;
23 compiled mutations killed; exact-output independent readers passed. This is a
generic contract handoff, not a completed media-workspace packet. No Atlas pin was changed.

## Contract to consume

A `TemporalPartitionView` retains its checked partition, ordered exact bins,
original alternative contributions and ledger. A cell exposes its mark, existing
RecallRef address, original score/posterior alternative and optional source target.
Navigation requires the mapping digest. Region geometry retains disconnected
intervals and point atoms. Bins delegate top-k to the checked readout; omitted
weight remains present. The viewer does not normalize, interpolate, smooth,
convert clocks, derive densities or construct probability states.

The scientific interchange remains `temporal-query/v0.1`; contextual decoding
requires the checked mapping and reexecutes the query. Normalized-score mass is
not calibrated probability. Support-only bounds are conditional possible-location
bounds, not confidence intervals. Uniform allocation does not establish fine
localization. External, unknown-location and unallocated support remain separate.

## Dependencies before rendering

1. Land the independently owned M1 neutral supplied-artifact provenance. Existing
   `ViewBasis.AlignmentRun` says raw posterior from an aligner run and cannot label
   arbitrary normalized scores honestly. The generic adapter creates no provenance
   claim in its place.
2. Admit actual media support in the workspace source/mapping package. The reviewed
   M1 candidate `f4af92e8` reconstructs a text-only SourceRepresentation. Its separate
   declared SourceTimeline is display metadata, not physical support. Do not graft
   those spans onto the existing mapping digest.
3. Compile the final scene in StoryModel using that admitted packet, then lower it
   in StoryAtlas. Workspace selection must bind through the existing contextual
   recall/source address bridge after verifying the selected policy mapping digest.

## Consumer acceptance

Compare every visible value with the retained scientific readout; preserve gaps,
point glyphs, support-only absence and all ledger categories. Wrong mapping/source/
axis joins must refuse before drawing. Identical local IDs from different mappings
must not share selection context. Crop, top-k and zoom must retain omitted and
outside mass; rebinning calls StoryModel's checked query. Use a non-colour cue for
unavailable data and label the measure/allocation assumption in accessible text.

The first visual slice is linked encoding bins plus a recall-unit inspector. Dense
recall-time heatmaps additionally require a checked recall-exposure policy; onsets
alone cannot fill the intervals between words. Scatter/point views remain possible
when actual timed events are admitted. Scanner mode requires an actual run binding,
not the synthetic declared-scanner label.

Qualify the exact producer/consumer SHA pair on JVM and JS, then loading, selection,
save/reopen and browser accessibility/export replay under the repository's existing
courts. No renderer, application or browser completion is claimed by this handoff.
