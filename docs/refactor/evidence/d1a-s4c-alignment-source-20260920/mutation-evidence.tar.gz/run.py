from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
repo=Path('/private/tmp/storymodel4s-d1a-s4c-20260920')
out=Path('/Users/bbuchsbaum/code/scala/storymodel4s/data/study/d1a-s4c-20260920')
label=sys.argv[1];args=sys.argv[2:]
command=['sbt','-batch','-Dstorymodel4s.grakern.build=/private/tmp/storymodel4s-film-consumer-20260919-9zqdg50z/grakern',*args]
def clean():return not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert clean();log=out/(label+'.log');assert not log.exists();started=time.time()
with log.open('w') as stream:
 stream.write('COMMAND '+json.dumps(command)+'\n');stream.flush();r=subprocess.run(command,cwd=repo,stdout=stream,stderr=subprocess.STDOUT);stream.write('\nCOMMAND_EXIT='+str(r.returncode)+'\n')
text=log.read_text();totals=[line for line in text.splitlines() if line.startswith(('[info] Passed: Total','[error] Failed: Total'))]
counts={k:0 for k in ['Total','Failed','Errors','Passed','Skipped']}
for line in totals:
 for key,value in re.findall(r'(Total|Failed|Errors|Passed|Skipped) (\d+)',line):counts[key]+=int(value)
receipt=dict(codeRevision=revision,command=command,exitCode=r.returncode,cleanBefore=True,cleanAfter=clean(),startedEpochSeconds=started,elapsedSeconds=time.time()-started,testTotals=totals,aggregateTestCounts=counts,logSha256=hashlib.sha256(log.read_bytes()).hexdigest())
(out/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));raise SystemExit(r.returncode)
