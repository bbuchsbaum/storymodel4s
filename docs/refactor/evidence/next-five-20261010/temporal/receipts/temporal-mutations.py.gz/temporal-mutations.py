import subprocess,json,sys
from pathlib import Path
root=Path('/Users/bbuchsbaum/code/scala/storymodel4s');clone=Path('/private/tmp/storymodel4s-s2b3-build')
out=root/'.agent-work/next-five-20261010';sha=sys.argv[1]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()==sha
assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone,text=True).strip()
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py'
sbt=['sbt','-batch','-Dstorymodel4s.grakern.build=/private/tmp/storymodel4s-workflow-grakern-pin','set ThisBuild / tlFatalWarnings := true']
def run(name,commands):
 p=subprocess.run(['python3',wrapper,'--log',str(out/(name+'.log')),'--cwd',str(clone),'--timeout','1800','--',*sbt,*commands],stdout=subprocess.DEVNULL)
 print(name,p.returncode,flush=True);return p.returncode,(out/(name+'.log')).read_text()
mutants=[
('inventory','temporalexposure.scala','if mapping.inventory.digest != timing.inventory.digest then','if false && mapping.inventory.digest != timing.inventory.digest then','exposure rejects foreign inventory'),
('overlap','temporalexposure.scala','if overlap == Overlap.Refuse && conflict then','if overlap == Overlap.Refuse && false && conflict then','overlap is refused or shared'),
('word-dedup','temporalexposure.scala','case (unit, left, right) if left <= a && b <= right => unit\n        }.distinct','case (unit, left, right) if left <= a && b <= right => unit\n        }','overlap is refused or shared'),
('support-only','temporalgrid.scala','c.resolvedBounds.exists(_.upper > 0.0) || c.allocated.exists(_ > 0.0)','c.allocated.exists(_ > 0.0)','sparse crop and rebin'),
('cropped-mass','temporalgrid.scala','whole.allocatedOutside,','whole.allocatedOutside * 0.0,','sparse crop and rebin'),
('atom-entry','temporalconcentration.scala','Vector(BigInt(p.at), BigInt(p.at) + 1)','Vector(BigInt(p.at), BigInt(p.at))','half-open atom concentration'),
('finite-transport','temporalquery.scala','Either.cond(components.map(_.weight).sum.isFinite, (), Refusal.NonFiniteAggregate)','Either.cond(true || components.map(_.weight).sum.isFinite, (), Refusal.NonFiniteAggregate)','finite transport entries cannot publish'),
]
results=json.loads((out/"temporal-mutations.json").read_text()) if (out/"temporal-mutations.json").exists() else []
mutants = [(name, str(Path('align/src/main/scala/storymodel4s/align')/file), old, new, 'alignJVM/testOnly *TemporalQuerySuite', witness) for name,file,old,new,witness in mutants]
mutants += json.loads((out/'temporal-mutant-plan.json').read_text())
for name,file,old,new,command,witness in mutants:
 if name in {r['mutant'].split('-clean')[0] for r in results}:continue
 rel=Path(file);p=clone/rel;original=p.read_text()
 commands=[command]
 if 'boundary' in name:
  scope=command.split('/')[0]
  suite=command.split('*')[1]
  commands=[f'set LocalProject("{scope}") / Test / sources := (LocalProject("{scope}") / Test / unmanagedSources).value.filter(_.getName == "{suite}.scala")',f'{scope}/Test/clean',command]
  if name == 'view-boundary':
   commands[0] = commands[0].replace('_.getName == "TemporalGridViewSuite.scala"', 'f => Set("TemporalGridViewSuite.scala", "TemporalQueryCodecSuite.scala").contains(f.getName)')
  name += '-clean3' 
 assert original.count(old)==1,name
 try:
  p.write_text(original.replace(old,new))
  (out/('temporal-mutant-'+name+'.patch.txt')).write_text(subprocess.check_output(['git','diff','--',str(rel)],cwd=clone,text=True))
  rc,log=run('temporal-mutant-'+name,commands)
  assert rc!=0 and 'done compiling' in log and '[error] --' not in log and any('==> X' in l and witness in l for l in log.splitlines()),name
  results.append({'sha':sha,'mutant':name,'compiled':True,'namedFailure':witness,'exit':rc,'totals':[l for l in log.splitlines() if 'Failed: Total' in l]})
  (out/'temporal-mutations.json').write_text(json.dumps(results,indent=2)+'\n')
 finally:p.write_text(original)
rc,_=run('temporal-core-restored',['alignJVM/testOnly *TemporalQuerySuite *TemporalExposureBoundarySuite *TemporalGridBoundarySuite *TemporalProjectionBoundarySuite']);assert rc==0
(out/'temporal-mutations.json').write_text(json.dumps(results,indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=clone,text=True).strip()
