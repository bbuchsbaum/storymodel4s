import subprocess,json,os,sys,re,hashlib
from pathlib import Path
root=Path('/Users/bbuchsbaum/code/scala/storymodel4s');clone=Path('/private/tmp/storymodel4s-s2b3-build');consumer=Path('/private/tmp/storyatlas4s-study-workflow');out=root/'.agent-work/next-five-20261010'
sha=sys.argv[1];base='198550727aa09dcc52d05662652c51f2565a79dd';consumer_sha='ac2ca6cb85fdb8a959390e0e3d16e7af87c3e16d'
wrapper='/Users/bbuchsbaum/.agents/skills/lean-logs/scripts/run_logged.py'
def git(cwd,*args):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
assert git(clone,'rev-parse','HEAD')==sha
assert not git(clone,'status','--porcelain')
assert git(consumer,'rev-parse','HEAD')==consumer_sha
subprocess.run(['git','diff','--exit-code','HEAD'],cwd=consumer,check=True)
scope=subprocess.run(['bash','tools/reference-scope.sh',base,sha],cwd=clone,capture_output=True,text=True)
(out/'temporal-reference-scope.txt').write_text(scope.stdout+scope.stderr);assert scope.returncode==0
receipt={'producer':sha,'localBase':base,'consumer':consumer_sha,'consumerSource':'explicit local source override; source pin not changed','grakern':git(Path('/private/tmp/storymodel4s-workflow-grakern-pin'),'rev-parse','HEAD'),'runs':[]}
def run(name,cwd,args,timeout=3600):
 p=subprocess.run(['python3',wrapper,'--log',str(out/(name+'.log')),'--cwd',str(cwd),'--timeout',str(timeout),'--',*args],stdout=subprocess.DEVNULL)
 log=(out/(name+'.log')).read_text()
 totals=[dict(zip(['total','failed','errors','passed'],map(int,m))) for m in re.findall(r'(?:Passed|Failed): Total (\d+), Failed (\d+), Errors (\d+), Passed (\d+)',log)]
 receipt['runs'].append({'name':name,'exit':p.returncode,'cells':len(totals),'totals':{key:sum(v[key] for v in totals) for key in ['total','failed','errors','passed']}})
 (out/'temporal-qualification.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,p.returncode,receipt['runs'][-1],flush=True)
 assert p.returncode==0,name
sbt=['sbt','-batch','-Dstorymodel4s.grakern.build=/private/tmp/storymodel4s-workflow-grakern-pin','set ThisBuild / tlFatalWarnings := true']
# Two new guards receive compiled counterfactuals before the restored full gate.
mutations = [
 ('weighted-overflow', 'align/src/main/scala/storymodel4s/align/temporalprojection.scala',
  'values.values.forall(_.isFinite)', 'true || values.values.forall(_.isFinite)',
  'alignJVM/testOnly *TemporalQuerySuite', 'duration-weighted transport overflow'),
 ('failed-request-identity', 'pipeline/src/main/scala/storymodel4s/pipeline/MappingPipeline.scala',
  None, None, 'pipeline/testOnly *TemporalPipelineSuite *TemporalProjectionConsumerContractSuite', 'failed temporal requests remain bound')
]
receipt['newMutations'] = []
for name,relative,old,new,command,witness in mutations:
 path=clone/relative;original=path.read_text()
 if old is None:
  start=original.index('                "request" -> outcome.observation')
  end=original.index('                "referenceProjection" ->',start)
  changed=original[:start]+'                "request" -> Json.Null,\n                "requestDigest" -> Json.Null,\n'+original[end:]
 else:
  assert original.count(old)==1
  changed=original.replace(old,new)
 try:
  path.write_text(changed)
  (out/('temporal-final-mutant-'+name+'.patch.txt')).write_text(git(clone,'diff','--',relative)+'\n')
  log=out/('temporal-final-mutant-'+name+'.log')
  result=subprocess.run(['python3',wrapper,'--log',str(log),'--cwd',str(clone),'--timeout','1200','--',*sbt,command],stdout=subprocess.DEVNULL)
  content=log.read_text()
  assert result.returncode!=0 and 'done compiling' in content and '[error] --' not in content and any('==> X' in line and witness in line for line in content.splitlines()),name
  receipt['newMutations'].append({'name':name,'sha':sha,'compiled':True,'witness':witness,'totals':[line for line in content.splitlines() if 'Failed: Total' in line]})
  print('MUTATION_KILLED',name,flush=True)
 finally:path.write_text(original)
assert not git(clone,'status','--porcelain')
run('temporal-final-gate',clone,sbt+['checkAll'])
facade=out/'temporal-facade-fixtures';workspace=out/'temporal-workspace-fixtures'
run('temporal-final-fixtures',clone,sbt+['codecJVM/Test/runMain storymodel4s.codec.TemporalProjectionFixtures','pipeline/Test/runMain storymodel4s.pipeline.TemporalPipelineWitness '+str(facade)+' '+sha,'pipeline/Test/runMain storymodel4s.pipeline.StudyWorkspaceWitness '+str(workspace)+' '+sha])
run('temporal-final-reader',clone,['python3','tools/test_temporal_projection.py',str(out/'temporal-final-fixtures.log'),str(facade)])
run('temporal-workspace-reader',clone,['python3','examples/mapping/test_workspace.py',str(workspace)])
fixtures=json.loads((workspace/'workspace-fixtures.json').read_text());assert fixtures['producerRevision']==sha
csbt=['sbt','-batch','-Dstoryatlas4s.storymodel4s.build='+str(clone),'-Dstorymodel4s.grakern.build=/private/tmp/storymodel4s-workflow-grakern-pin','set ThisBuild / tlFatalWarnings := true']
run('temporal-consumer',consumer,csbt+['-Dstoryatlas.surfaceWorkspace.fixture='+fixtures['text'],'compileAll','testAll','scalafmtCheckAll','scalafmtSbtCheck'])
run('temporal-consumer-timed',consumer,csbt+['-Dstoryatlas.surfaceWorkspace.fixture='+fixtures['timed'],'shellJVM/testOnly storyatlas4s.shell.SurfaceWorkspaceControllerSuite'])
assert not git(clone,'status','--porcelain')
subprocess.run(['git','diff','--exit-code','HEAD'],cwd=consumer,check=True)
print('ALL_TEMPORAL_QUALIFICATION_PASSED',sha,flush=True)
