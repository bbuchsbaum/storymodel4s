package storymodel4s.align
import munit.FunSuite
class SinkhornRuntimeParitySuite extends FunSuite:
  test("preserved baseline matches the exact pre-numerical-source implementation on this runtime") {
    val inputs = Vector(
      (
        Vector(Vector(0.1, 0.3, 0.5), Vector(0.6, 0.2, 0.4)),
        Vector(0.4, 0.6),
        Vector(0.2, 0.3, 0.5)
      ),
      (Vector(Vector(0.1, 0.9), Vector(0.8, 0.2)), Vector(0.0, 1.0), Vector(0.6, 0.4)),
      (
        Vector(Vector(0.0, Double.PositiveInfinity), Vector(Double.PositiveInfinity, 0.0)),
        Vector(1.0, 1.0),
        Vector(1.0, 1.0)
      ),
      (Vector(Vector(1e-10, 0.3), Vector(0.2, 1e-10)), Vector(1e-30, 1.0), Vector(0.5, 0.5)),
      (Vector(Vector(Double.NaN)), Vector(1.0), Vector(1.0)),
      (Vector(Vector(0.0)), Vector(Double.PositiveInfinity), Vector(1.0)),
      (Vector(Vector(Double.PositiveInfinity)), Vector(1.0), Vector(1.0))
    )
    val generated = (1 to 64).toVector.map(i =>
      (
        Vector(
          Vector((i % 13) * 0.0137, (i % 17) * 0.0321),
          Vector((i % 19) * 0.0723, (i % 23) * 0.0461)
        ),
        Vector(0.4, 0.6),
        Vector(0.35, 0.65)
      )
    )
    val configs = Vector(
      SinkhornConfig(),
      SinkhornConfig(epsilon = 0.03, rhoRows = 0.0),
      SinkhornConfig(epsilon = 0.2, rhoCols = 0.0),
      SinkhornConfig(maxIterations = 3)
    )
    for (cost, a, b) <- (inputs ++ generated); config <- configs do
      assertEquals(
        UnbalancedSinkhorn.solve(cost, a, b, config),
        LegacyRuntimeSinkhorn.solve(cost, a, b, config)
      )
  }
